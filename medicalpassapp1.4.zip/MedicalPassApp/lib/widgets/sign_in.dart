import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:medicalpassapp/flutter_flow/navbar.dart';
import 'package:medicalpassapp/user.dart';
import 'package:medicalpassapp/widgets/sign_up.dart';
import '../theme.dart';
import 'snackbar.dart';
import 'package:http/http.dart' as http;
import 'package:mongo_dart/mongo_dart.dart' as mongo;

class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);

  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  TextEditingController loginEmailController = TextEditingController();
  TextEditingController loginPasswordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  bool _obscureTextPassword = true;

  User user = User("", "", "", "", "", "");

  String url = "http://192.168.15.165:8080/login";

  Future find() async {

    String email, cel, cpf, nome;

    var res = await http.post(Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'email': user.email, 'password': user.password, 'celular': user.celular, 'cpf': user.cpf, 'nome': user.nome}));
    print(res.body.length);

    var values = json.decode(res.body);
    var getCel = values['celular'];
    var getCPF = values['cpf'];
    var getNome = values['nome'];

    if(res.body.length < 1000){

      email = user.email;
      cel = getCel;
      cpf = getCPF;
      nome = getNome;

      Navigator.push(context,MaterialPageRoute(builder: (context) => NavBarWidget(email, cel, cpf, nome)));
    }else if(res.body.length > 1000){
      CustomSnackBarError(context, const Text('Usuário ou senha incorretos'));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage('assets/images/login.png'), fit: BoxFit.cover),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(left: 35, top: 130),
              child: Text(
                'Bem-vindo(a) ao MedPass',
                style: TextStyle(color: Colors.white, fontSize: 33),
              ),
            ),
            SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Container(
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 35, right: 35),
                        child: Column(
                          children: [
                            TextFormField(
                              controller: TextEditingController(text: user.email),
                              style: TextStyle(color: Colors.black),
                              onChanged: (val) {
                                user.email = val;
                              },
                              validator: (value) {
                                if (value!.isEmpty) return "Email está em branco";
                                return null;
                              },
                              decoration: InputDecoration(
                                  fillColor: Colors.grey.shade100,
                                  filled: true,
                                  hintText: "Email",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  )),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            TextFormField(
                              controller: TextEditingController(text: user.password),
                              style: TextStyle(color: Colors.black),
                              onChanged: (val) {
                                user.password = val;
                              },
                              validator: (value) {
                                if (value!.isEmpty) return "Senha está em branco";
                                return null;
                              },
                              obscureText: true,
                              decoration: InputDecoration(
                                  fillColor: Colors.grey.shade100,
                                  filled: true,
                                  hintText: "Senha",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  )),
                            ),
                            SizedBox(
                              height: 40,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Entrar',
                                  style: TextStyle(
                                      fontSize: 27, fontWeight: FontWeight.w700),
                                ),
                                CircleAvatar(
                                  radius: 30,
                                  backgroundColor: Color(0xff4c505b),
                                  child: IconButton(
                                      color: Colors.white,
                                      onPressed: () {
                                        if(_formKey.currentState!.validate()){
                                          find();
                                        }
                                      },
                                      icon: Icon(
                                        Icons.arrow_forward,
                                      )),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 40,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SignUp()));
                                  },
                                  child: Text(
                                    'Cadastre-se',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                        decoration: TextDecoration.underline,
                                        color: Color(0xff4c505b),
                                        fontSize: 18),
                                  ),
                                  style: ButtonStyle(),
                                ),
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              )
            ),
          ],
        ),
      ),
    );
  }

  void _toggleLogin() {
    setState(() {
      _obscureTextPassword = !_obscureTextPassword;
    });
  }
}