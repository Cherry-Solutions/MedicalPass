class User {
  String email;
  String password;
  String celular;
  String cpf;
  String rg;
  String nome;
  User(this.email, this.password, this.celular, this.cpf, this.rg, this.nome);
}