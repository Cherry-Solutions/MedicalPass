import 'dart:async';

import 'package:medicalpassapp/confirmations_page/planoAddRealizadoPage.dart';
import 'package:medicalpassapp/flutter_flow/navbar.dart';

import '../flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TudoProntoCopy2Widget extends StatefulWidget {
  String email, cel, cpf, nome;

  TudoProntoCopy2Widget(this.email, this.cel, this.cpf, this.nome, {super.key});

  @override
  _TudoProntoCopy2WidgetState createState() => _TudoProntoCopy2WidgetState();
}

class _TudoProntoCopy2WidgetState extends State<TudoProntoCopy2Widget> {

  late Timer _timer;
  int _start = 8;

  void startTimer() {

    String email = widget.email;
    String cpf = widget.cpf;
    String cel = widget.cel;
    String nome = widget.nome;

    const oneSec = const Duration(seconds: 8);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          Navigator.push(context,MaterialPageRoute(builder: (context) => NavBarWidget(email, cel, cpf, nome)));
        }
      },
    );
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {

    startTimer();

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF97FBA8),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: AlignmentDirectional(0, 0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 50, 0, 0),
                  child: Image.asset(
                    'assets/images/TudoPronto.png',
                    width: 350,
                    height: 350,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0, 0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                  child: Text(
                    'Pedido Realizado',
                    style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0, 0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(30, 10, 30, 0),
                  child: Text(
                    'Seu pedido será processado dentro de no máximo 1 dia !\nVocê sera redirecionado em 5s.',
                    style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
