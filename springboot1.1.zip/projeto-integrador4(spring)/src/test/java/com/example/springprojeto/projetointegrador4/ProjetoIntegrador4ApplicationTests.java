package com.example.springprojeto.projetointegrador4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoIntegrador4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
