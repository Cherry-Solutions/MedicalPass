import 'package:medicalpassapp/flutter_flow/historic_page.dart';
import 'package:medicalpassapp/flutter_flow/home_page.dart';
import 'package:medicalpassapp/flutter_flow/profile_page.dart';

import 'flutter_flow_theme.dart';
import 'package:flutter/material.dart';

class NavBarWidget extends StatefulWidget {

  const NavBarWidget({Key? key}) : super(key: key);

  @override
  _NavBarWidgetState createState() => _NavBarWidgetState();
}

class _NavBarWidgetState extends State<NavBarWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  int _indiceAtual = 0;
  final List<Widget> _telas = [
    HomePageWidget(),
    ProfilePageWidget(),
    HistoricPageWidget()
  ];

  void onTabTapped(int index) {
    setState(() {
      _indiceAtual = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _telas[_indiceAtual],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Perfil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Histórico',
          ),
        ],
      ),
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
    );
  }
}
