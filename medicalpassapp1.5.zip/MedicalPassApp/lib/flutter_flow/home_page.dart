import 'package:medicalpassapp/widgets/sign_in.dart';

import '../mapsHP.dart';
import 'flutter_flow_icon_button.dart';
import 'flutter_flow_theme.dart';
import 'flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mongo_dart/mongo_dart.dart' as mongo;

class HomePageWidget extends StatefulWidget {

  String email, cel, cpf, nome;

  HomePageWidget(this.email, this.cpf, this.cel, this.nome, {super.key});

  @override
  _HomePageWidgetState createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget>{
  final scaffoldKey = GlobalKey<ScaffoldState>();

  String? stateValue;

  bool loading = true;
  List<Map<String, dynamic>>? ps = [];

  Future<List<Map<String, dynamic>>?> getData () async {

    var db = await mongo.Db.create("mongodb+srv://lucascherri:lucascherri123@cluster0.28xfnwn.mongodb.net/cadastros?retryWrites=true&w=majority");
    await db.open();

    var col = db.collection('planos_de_saude');

    var doc = await col.find(mongo.where.eq('email', widget.email)).toList();

    List<Map<String, dynamic>>? data = doc;

    return data;
  }

  @override
  void initState() {
    super.initState();
    loadPS();
  }

  void loadPS([bool showSpinner = false]) {
    if (showSpinner) {
      setState(() {
        loading = true;
      });
    }

    getData().then((data) {
      setState(() {
        ps = data;
        loading = false;
      });
    });
  }


  @override
  Widget build(BuildContext context) {

    String email = widget.email;
    String cpf = widget.cpf;
    String cel = widget.cel;
    String nome = widget.nome;

    return Scaffold(
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
        },
        backgroundColor: Color(0xFFAAFCB8),
        elevation: 8,
        child: FlutterFlowIconButton(
          borderColor: Colors.transparent,
          borderRadius: 30,
          borderWidth: 1,
          buttonSize: 50,
          icon: Icon(
            Icons.message,
            color: FlutterFlowTheme.of(context).primaryText,
            size: 30,
          ),
          onPressed: () {
            loadPS(true);
          },
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Align(
                      alignment: AlignmentDirectional(-0.75, 0),
                      child: Text(
                        'Início',
                        style: FlutterFlowTheme.of(context).bodyText1.override(
                          fontFamily: 'Poppins',
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(-0.05, 0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 20, 0),
                          child: FlutterFlowIconButton(
                            borderColor: Colors.transparent,
                            borderRadius: 30,
                            borderWidth: 1,
                            buttonSize: 40,
                            icon: FaIcon(
                              FontAwesomeIcons.externalLinkAlt,
                              color: FlutterFlowTheme.of(context).primaryText,
                              size: 20,
                            ),
                            onPressed: () {
                              Navigator.push(context,MaterialPageRoute(builder: (context) => SignIn()));
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(30, 30, 30, 0),
                child: Container(
                  width: double.infinity,
                  height: 140,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 4,
                        color: Color(0x33000000),
                        offset: Offset(0, 2),
                      )
                    ],
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional(-0.8, 1),
                          child: Text(
                            'Sua Consulta',
                            textAlign: TextAlign.start,
                            style: FlutterFlowTheme.of(context)
                                .bodyText1
                                .override(
                              fontFamily: 'Poppins',
                              color:
                              FlutterFlowTheme.of(context).primaryColor,
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional(-0.85, -0.4),
                          child: Text(
                            'Instituição:',
                            style: FlutterFlowTheme.of(context).bodyText1,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional(-0.7, -0.9),
                          child: Text(
                            'Tempo de espera estimado:',
                            style: FlutterFlowTheme.of(context).bodyText1,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Align(
                          alignment: AlignmentDirectional(0, -0.5),
                          child: FFButtonWidget(
                            onPressed: () {
                              print('Button pressed ...');
                            },
                            text: '+ Mais Inf.',
                            options: FFButtonOptions(
                              width: 90,
                              height: 20,
                              color: Color(0xFFAAFCB8),
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 8,
                              ),
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(30, 60, 30, 0),
                child: new GestureDetector(
                  onTap: (){
                    Navigator.push(context,MaterialPageRoute(builder: (context) => mapsHP(email, cpf, cel, nome)));
                  },
                  child: Container(
                    width: double.infinity,
                    height: 140,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      image: DecorationImage(
                        opacity: 140,
                        fit: BoxFit.cover,
                        image: Image.network(
                          'https://img.freepik.com/premium-vector/urban-city-vector-map-town-streets-gps-navigation-downtown-plan-with-roads-parks-river_461812-589.jpg?w=2000',
                        ).image,
                      ),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 4,
                          color: Color(0x33000000),
                          offset: Offset(0, 2),
                        )
                      ],
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(
                        color: FlutterFlowTheme.of(context).primaryBtnText,
                      ),
                    ),
                    child: Align(
                      alignment: AlignmentDirectional(0, 0.20),
                      child: Text(
                        'Encontre sua próxima consulta\n',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodyText1.override(
                          fontFamily: 'Poppins',
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFFAAFCB8),
                        ),
                      ),
                    ),
                  ),
                )
              ),
              Align(
                alignment: AlignmentDirectional(-0.75, -0.65),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                  child: Text(
                    'Seus planos',
                    textAlign: TextAlign.start,
                    style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Container(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                          height: 200,
                          child: FutureBuilder(
                            future: getData(),
                            builder: (context, snapshot){
                              if(snapshot.hasData){
                                return ListView.builder(
                                    itemCount: snapshot.data!.length,
                                    scrollDirection: Axis.vertical,
                                    itemBuilder: (context, index){
                                      return Align(
                                        alignment: AlignmentDirectional(0, 0),
                                        child: Padding(
                                          padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 0),
                                          child: Container(
                                            width: 1000,
                                            height: 100,
                                            decoration: BoxDecoration(
                                              color: FlutterFlowTheme.of(context).secondaryBackground,
                                              boxShadow: [
                                                BoxShadow(
                                                  blurRadius: 4,
                                                  color: Color(0x33000000),
                                                  offset: Offset(0, 2),
                                                )
                                              ],
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Padding(
                                                  padding:
                                                  EdgeInsetsDirectional.fromSTEB(20, 20, 20, 0),
                                                  child: Row(
                                                    mainAxisSize: MainAxisSize.max,
                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Expanded(
                                                        child: Align(
                                                          alignment: AlignmentDirectional(-1, -1),
                                                          child: Text(
                                                            'Instituição: ${snapshot.data![index]['instituicao']}',
                                                            textAlign: TextAlign.start,
                                                            style:
                                                            FlutterFlowTheme.of(context).bodyText1,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
                                                  child: Row(
                                                    mainAxisSize: MainAxisSize.max,
                                                    children: [
                                                      Text(
                                                        'Plano: ${snapshot.data![index]['plano']}',
                                                        style: FlutterFlowTheme.of(context).bodyText1,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
                                                  child: Row(
                                                    mainAxisSize: MainAxisSize.max,
                                                    children: [
                                                      Text(
                                                        'Nº Registro: ${snapshot.data![index]['numero_registro']}',
                                                        style: FlutterFlowTheme.of(context).bodyText1,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    }
                                );
                              }else{
                                return Center(
                                    child: Text("Analisando...")
                                );
                              }
                            },
                          )
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
