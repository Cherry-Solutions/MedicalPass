import 'package:medicalpassapp/confirmations_page/planoAddRealizadoPage.dart';
import 'package:medicalpassapp/flutter_flow/navbar.dart';
import 'package:mongo_dart/mongo_dart.dart' as mongo;
import '../flutter_flow/flutter_flow_drop_down.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';

class AddPlanoDeSaudePageWidget extends StatefulWidget {

  String email, cel, cpf, nome;

  AddPlanoDeSaudePageWidget(this.email, this.cel, this.cpf, this.nome, {super.key});

  @override
  _AddPlanoDeSaudePageWidgetState createState() =>
      _AddPlanoDeSaudePageWidgetState();
}

class _AddPlanoDeSaudePageWidgetState extends State<AddPlanoDeSaudePageWidget> {

  final _formKey = GlobalKey<FormState>();

  String? stateValue1;
  String? stateValue2;
  TextEditingController? textController;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  
  Future<void> addPS() async {

    String email = widget.email;
    String cpf = widget.cpf;
    String cel = widget.cel;
    String nome = widget.nome;

    var db = await mongo.Db.create("mongodb+srv://lucascherri:lucascherri123@cluster0.28xfnwn.mongodb.net/cadastros?retryWrites=true&w=majority");
    await db.open();

    var col = db.collection('planos_de_saude');
    col.insertOne({
      'email' : email,
      'instituicao' : stateValue1,
      'plano' : stateValue2,
      'numero_registro' : stateValue2
    });

    Navigator.push(context,MaterialPageRoute(builder: (context) => TudoProntoCopy2Widget(email, cel, cpf, nome)));

  }

  @override
  Widget build(BuildContext context) {

    String email = widget.email;
    String cpf = widget.cpf;
    String cel = widget.cel;
    String nome = widget.nome;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100),
        child: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30,
            borderWidth: 1,
            buttonSize: 40,
            icon: Icon(
              Icons.arrow_back_ios_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 25,
            ),
            onPressed: () {
              //Navigator.push(context,MaterialPageRoute(builder: (context) => NavBarWidget(email, cel, cpf, nome)));
              print(stateValue2);
            },
          ),
          title: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                'Adicione um novo plano',
                style: FlutterFlowTheme.of(context).bodyText1.override(
                  fontFamily: 'Poppins',
                  fontSize: 20,
                ),
              ),
            ],
          ),
          actions: [],
          centerTitle: true,
          elevation: 0,
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 16),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 12),
                  child: FlutterFlowDropDown(
                    options: <String>["Hospital Vera Cruz", "Clínica da Cidade"],
                    onChanged: (val) => setState(() => stateValue1 = val),
                    width: double.infinity,
                    height: 56,
                    textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Outfit',
                      color: Color(0xFF101213),
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                    ),
                    hintText: 'Instituição',
                    icon: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Color(0xFF57636C),
                      size: 15,
                    ),
                    fillColor: Colors.white,
                    elevation: 2,
                    borderColor: Color(0xFFE0E3E7),
                    borderWidth: 2,
                    borderRadius: 8,
                    margin: EdgeInsetsDirectional.fromSTEB(20, 4, 12, 4),
                    hidesUnderline: true,
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 12),
                  child: FlutterFlowDropDown(
                    options: <String>["Unimed", "Bradesco", "Notredame"],
                    onChanged: (val) => setState(() => stateValue2 = val),
                    width: double.infinity,
                    height: 56,
                    textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Outfit',
                      color: Color(0xFF101213),
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                    ),
                    hintText: 'Plano de Saúde',
                    icon: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Color(0xFF57636C),
                      size: 15,
                    ),
                    fillColor: Colors.white,
                    elevation: 2,
                    borderColor: Color(0xFFE0E3E7),
                    borderWidth: 2,
                    borderRadius: 8,
                    margin: EdgeInsetsDirectional.fromSTEB(20, 4, 12, 4),
                    hidesUnderline: true,
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 12),
                  child: Container(
                    width: double.infinity,
                    child: TextFormField(
                      controller: textController,
                      validator: (value) {
                        if (value!.isEmpty) return "Número de registro está em branco";
                        return null;
                      },
                      autofocus: true,
                      obscureText: false,
                      decoration: InputDecoration(
                        labelText: 'Nº de Registro',
                        hintStyle: FlutterFlowTheme.of(context).bodyText2.override(
                          fontFamily: 'Poppins',
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFFE0E3E7),
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFFE0E3E7),
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFFF24236),
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFFF24236),
                            width: 2,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      style: FlutterFlowTheme.of(context).bodyText1.override(
                        fontFamily: 'Poppins',
                        color: Color(0xFF101213),
                        fontWeight: FontWeight.normal,
                      ),
                      keyboardType: TextInputType.number,
                      maxLength: 14,
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(0, 0.05),
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(20, 70, 20, 0),
                    child: FFButtonWidget(
                      onPressed: () {
                        if(_formKey.currentState!.validate()){
                          addPS();
                        }
                      },
                      text: 'PROSSEGUIR',
                      options: FFButtonOptions(
                        width: double.infinity,
                        height: 50,
                        color: Color(0xFF4361EE),
                        textStyle: FlutterFlowTheme.of(context).subtitle1.override(
                          fontFamily: 'Outfit',
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.normal,
                        ),
                        elevation: 2,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
