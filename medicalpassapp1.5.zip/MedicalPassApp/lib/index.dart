// Export pages
export 'package:medicalpassapp/flutter_flow/profile_page.dart' show ProfilePageWidget;
export 'package:medicalpassapp/flutter_flow/home_page.dart' show HomePageWidget;
export 'package:medicalpassapp/flutter_flow/historic_page.dart' show HistoricPageWidget;
