import 'package:flutter/material.dart';
import 'package:medicalpassapp/widgets/sign_in.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SignIn(),
  ));
}