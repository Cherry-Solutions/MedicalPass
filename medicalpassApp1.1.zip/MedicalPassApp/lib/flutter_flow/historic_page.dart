import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:medicalpassapp/flutter_flow/home_page.dart';
import 'package:medicalpassapp/flutter_flow/profile_page.dart';

import '../flutter_flow/flutter_flow_theme.dart';
import 'package:flutter/material.dart';

class HistoricPageWidget extends StatefulWidget {
  const HistoricPageWidget({Key? key}) : super(key: key);

  @override
  _HistoricPageWidgetState createState() => _HistoricPageWidgetState();
}

class _HistoricPageWidgetState extends State<HistoricPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Align(
                  alignment: AlignmentDirectional(-0.55, -0.95),
                  child: Text(
                    'Histórico de Consulta',
                    style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              GNav(
                  backgroundColor: Colors.black,
                  color: Colors.white,
                  activeColor: Colors.white,
                  tabBackgroundColor: Colors.grey.shade800,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20), // navigation bar padding
                  tabs: [
                    GButton(
                      icon: Icons.person,
                      text: 'Perfil',
                      onPressed: (){
                        //Navigator.push(context,MaterialPageRoute(builder: (context) => ProfilePageWidget()));
                      },
                    ),
                    GButton(
                      icon: Icons.house,
                      text: 'Início',
                      onPressed: (){
                        //Navigator.push(context,MaterialPageRoute(builder: (context) => HomePageWidget()));
                      },
                    ),
                    GButton(
                      icon: Icons.history,
                      text: 'Histórico',
                      onPressed: (){
                        //Navigator.push(context,MaterialPageRoute(builder: (context) => HistoricPageWidget()));

                      },
                    ),
                  ]
              ),
            ],
          ),
        ),
      ),
    );
  }
}
