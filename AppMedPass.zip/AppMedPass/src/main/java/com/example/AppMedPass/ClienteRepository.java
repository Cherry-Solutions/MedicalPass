package com.example.AppMedPass;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ClienteRepository extends MongoRepository<Paciente, String> {

    Paciente findByCPF(String CPF);
    List<Paciente> findByEmail(String email);

}
