package com.example.AppMedPass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppMedPassApplication implements CommandLineRunner {

	@Autowired
	private ClienteRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(AppMedPassApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// save a couple of customers
		repository.save(new Paciente("Cesar", "cesaraugusto@gmail.com", "90908989", "178543789", "19 9 99341307"));

		// fetch all customers
		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Paciente paciente : repository.findAll()) {
			System.out.println(paciente);
		}
		System.out.println();

		// fetch an individual customer
		System.out.println("Customer found with CPF('321123654'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByCPF("321123654"));

		System.out.println("Customers found with email('lucascherri@gmail.com'):");
		System.out.println("--------------------------------");
		for (Paciente paciente : repository.findByEmail("lucascherri@gmail.com")) {
			System.out.println(paciente);
		}

	}

}
