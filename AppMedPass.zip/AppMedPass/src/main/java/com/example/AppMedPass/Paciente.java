package com.example.AppMedPass;

import org.springframework.data.annotation.Id;

public class Paciente {

    @Id
    public String id;
    public String nome;
    public String RG;
    public String CPF;
    public String celular;
    public String email;

    public Paciente() {}

    public Paciente(String nome, String email, String RG, String CPF, String celular) {
        this.nome = nome;
        this.email = email;
        this.RG = RG;
        this.CPF = CPF;
        this.celular = celular;
    }

    @Override
    public String toString() {
        return String.format(
                "Customer[id=%s, nome='%s', email='%s']",
                id, nome, email);
    }

}