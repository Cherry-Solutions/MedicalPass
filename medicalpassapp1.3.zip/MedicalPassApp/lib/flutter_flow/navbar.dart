import 'package:medicalpassapp/flutter_flow/historic_page.dart';
import 'package:medicalpassapp/flutter_flow/home_page.dart';
import 'package:medicalpassapp/flutter_flow/navbar.dart';
import 'package:medicalpassapp/flutter_flow/profile_page.dart';

import 'flutter_flow_theme.dart';
import 'package:flutter/material.dart';

class NavBarWidget extends StatefulWidget {

  String email, senha, cel, cpf, nome;

  NavBarWidget(this.email, this.senha, this.cel, this.cpf, this.nome, {super.key});

  //const NavBarWidget({Key? key}) : super(key: key);

  @override
  _NavBarWidgetState createState() => _NavBarWidgetState();
}

class _NavBarWidgetState extends State<NavBarWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  late String email = widget.email;
  late String password = widget.senha;
  late String cel = widget.cel;
  late String cpf = widget.cpf;
  late String nome = widget.nome;

  int _indiceAtual = 0;
  late List<Widget> _telas = [
    HomePageWidget(email, password),
    ProfilePageWidget(email, cel, cpf, nome, password),
    HistoricPageWidget()
  ];

  void onTabTapped(int index) {
    setState(() {
      _indiceAtual = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _telas[_indiceAtual],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Perfil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Histórico',
          ),
        ],
      ),
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
    );
  }
}
